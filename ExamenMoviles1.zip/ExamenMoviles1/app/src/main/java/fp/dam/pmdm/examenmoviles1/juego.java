package fp.dam.pmdm.examenmoviles1;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class juego extends AppCompatActivity {

    int valorClick = 1;

    Button Play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);
        valorClick = getIntent().getIntExtra("valorClick", 1);
        Play = (Button)
    }

}
