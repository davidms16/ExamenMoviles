package fp.dam.pmdm.examenmoviles1;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;

public class menu_principal  extends AppCompatActivity {

    Button Salir;

    Button Cronometro;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Cronometro = findViewById(R.id.button6);
        Salir = findViewById(R.id.button7);

        Salir.setOnClickListener(new view.onClickListener() {
            @Override
            public void onClick(View view) {
                irSalida();
            }

        });
        Cronometro.setOnClickListener(new View.activity);
    }

}

